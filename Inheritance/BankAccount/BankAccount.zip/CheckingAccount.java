/* 
Programmer Name: Johnny Olmedo
Date: 03/26/2022
Class: CSC 372
Assignment: Module 1 Option 1
*/
public class CheckingAccount extends BankAccount {
    double interestRate = 0.2;
    double balance;
    // will display a negative balance that includes a $30 overdraft fee and denotes that a fee has been accessed
    public void processWithdrawal() {
        //withdrawal(withdrawal);
        System.out.println("$30 overdraft fee applied to account");
        System.out.println("Balance: " + (getBalance() - 30));
    
    } 
    
    // should display all superclass attributes and provides an additional interest rate
    // @Override
    public void displayAccount() {
        super.accountSummary();
        if (getBalance() < 0) {
            processWithdrawal();
            System.out.print("Interest Rate: " + interestRate);
        }
        

    }
}
